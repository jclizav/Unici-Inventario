<?php $__env->startSection('content'); ?>
    <!-- Contenido principal -->
    <div class="flex-1 p-8 -ml-16">
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold text-gray-700">Reportes</h1>
            <a href="#" class="px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600">Añadir Departamento</a>
        </div>

        <!-- Formulario para agregar departamentos -->

        <!-- Tabla para listar departamentos -->
        <div class="overflow-x-auto">
            <table class="min-w-full border border-collapse border-gray-300">
                <thead>
                    <tr class="bg-gray-200"> 
                        <th class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300">Departamento/Área</th> 
                        <th class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300">Responsable del bien</th>
                        <th class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300">Bien</th> 
                        <th class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300">Estado</th>
                        <th class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300">Factura</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Ejemplo de datos estáticos -->
                    <?php $__currentLoopData = $Datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-100">
                            <td class="px-4 py-2 text-sm text-gray-600 border border-gray-300"><?php echo e($Dato->Area); ?></td> 
                            <td class="px-4 py-2 text-sm text-gray-600 border border-gray-300"><?php echo e($Dato->ResponsableBien); ?></td>
                            <td class="px-4 py-2 text-sm text-gray-600 border border-gray-300"><?php echo e($Dato->Bien); ?></td> 
                            <td class="px-4 py-2 text-sm text-gray-600 border border-gray-300"><?php echo e($Dato->Estado); ?></td> 
                            <td class="px-4 py-2 text-sm text-gray-600 border border-gray-300"><?php echo e($Dato->Factura); ?></td>
                        </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEDRICK\Documents\Residencia\Unici-Inventario\resources\views/reportes.blade.php ENDPATH**/ ?>