<?php $__env->startSection('content'); ?>
    <!-- Contenido principal -->
    <div class="flex-1 p-8">
        <div class="flex items-center justify-between mb-4">
            <h1 class="text-2xl font-bold text-gray-700">Editar Dato</h1>
        </div>

        <!-- Formulario para agregar departamentos -->

        <!-- Tabla para listar departamentos -->
        <div class="overflow-x-auto">
            <form action="<?php echo e(route('editN.up', ['id' => $Datos->id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                    <?php
                    $campos = [
                        'CodigoDeBarras' => 'Código de barras',
                        'IdNomenclatura' => 'Nomenclatura',
                        'Campus' => 'Campus',
                        'Area' => 'Departamento/Área',
                        'ResponsableArea' => 'Responsable del Área',
                        'ResponsableBien' => 'Responsable del bien',
                        'Bien' => 'Bien',
                        'Marca' => 'Marca',
                        'Modelo' => 'Modelo',
                        'Color' => 'Color',
                        'NumSerie' => 'Número de serie',
                        'Sat' => 'SAT',
                        'Fecha' => 'Adquisición',
                        'Precio' => 'Precio',
                        'CodigoCFiscal' => 'Conta Fiscal',
                        'Estado' => 'Estado',
                        'Descripcion' => 'Descripción',
                        'Observaciones' => 'Observaciones',
                        'Factura' => 'Factura',
                        'Imagen' => 'Imagen',
                        'Medida' => 'Unidad',
                    ];
                ?>

                <?php $__currentLoopData = $campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h2 class="px-4 py-2 text-sm font-semibold text-left text-gray-700 border border-gray-300"><?php echo e($label); ?></h2>
                    <input class="w-full px-4 py-2 mb-2 text-sm text-gray-600 border border-gray-300" 
                        name="<?php echo e($campo); ?>" 
                        value="<?php echo e($Datos->$campo); ?>"
                        type="text" 
                        >
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <button class="w-full p-2"> Actualizar </button> 
            </form>

        </div>

    </div>
         
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CEDRICK\Documents\Residencia\Unici-Inventario\resources\views/Edit.blade.php ENDPATH**/ ?>